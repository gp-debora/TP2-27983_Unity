using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GameOver : MonoBehaviour
{
    [SerializeField]
    private TMPro.TextMeshProUGUI highScore;

    private void OnEnable()
    {
        highScore.text = $"HighScore: {GameManager.Instance.HighScore}";
        var rectTransform = GetComponent<RectTransform>();
        rectTransform.anchoredPosition = new Vector2(0, rectTransform.rect.height);

        LeanTween.moveY(rectTransform, 0f, 1f).setEaseOutElastic().delay = 0.5f;
    }

    public void Restart()
    {
        gameObject.SetActive(false);
        GameManager.Instance.Enable();
    }

    public void Quit()
    {
#if UNITY_EDITOR
        EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
