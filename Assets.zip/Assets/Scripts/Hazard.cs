using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;


public class Hazard : MonoBehaviour
{
    Vector3 rotation;
    
    [SerializeField]
    private ParticleSystem breakingEffect;

    private CinemachineImpulseSource cinemachineImpulseSource;


    private void Start()
    {
        cinemachineImpulseSource = GetComponent<CinemachineImpulseSource>();

        var xRotation = Random.Range(0.2f, 0.6f);
        rotation = new Vector3(-xRotation, 1);
    }

    private void Update()
    {
        transform.Rotate(rotation);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (!collision.gameObject.CompareTag("Hazard"))
        {
            Destroy(gameObject);
            Instantiate(breakingEffect, transform.position, Quaternion.identity);
            cinemachineImpulseSource.GenerateImpulse();

        }
    }

}
